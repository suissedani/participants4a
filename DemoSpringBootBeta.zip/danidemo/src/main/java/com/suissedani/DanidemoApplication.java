package com.suissedani;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.suissedani")
public class DanidemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DanidemoApplication.class, args);
	}
}
