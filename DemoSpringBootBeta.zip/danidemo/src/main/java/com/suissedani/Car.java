package com.suissedani;

public class Car {

	private String VIN;
	private String color;
	private Integer miles;

	public String getVIN() {
		return VIN;
	}

	public String getColor() {
		return color;
	}

	public Integer getMiles() {
		return miles;
	}

	public void setVIN(String vIN) {
		VIN = vIN;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setMiles(Integer miles) {
		this.miles = miles;
	}
	
	

}
